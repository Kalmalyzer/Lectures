
#ifndef TYPES_H
#define TYPES_H

typedef unsigned int uint;
typedef unsigned char u8;
typedef char s8;
typedef unsigned short u16;
typedef short s16;
typedef unsigned int u32;
typedef short s32;

#endif
