These example programs have been developed using Microsoft Visual C++ 2010 Express Edition, with the Windows SDK installed.

TinyPTC is by gaffer, sourced from http://sourceforge.net/projects/tinyptc/files/

The example images are sourced from the net. They are drawn by:
OldSkool - by Rodney/TBL, aka Per-Anders Gustafsson
pic2 - by Louie/TBL, aka Kenny Magnusson
